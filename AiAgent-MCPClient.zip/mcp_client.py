import asyncio
import json
import subprocess
from typing import List, Dict, Any
from openai import OpenAI
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

class MCPClient:
    """MCP Client to communicate with MCP servers."""
    
    def __init__(self, server_command: List[str]):
        self.server_command = server_command
        self.process = None
        self.available_tools = []
        self.available_resources = []
    
    async def start_server(self):
        """Start the MCP server process."""
        self.process = await asyncio.create_subprocess_exec(
            *self.server_command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        # Initialize connection
        await self._send_message({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {}
            }
        })
        
        # Get available tools and resources
        await self._list_tools()
        await self._list_resources()
    
    async def _send_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Send a message to the MCP server and get response."""
        if not self.process:
            raise RuntimeError("Server not started")
        
        message_str = json.dumps(message) + "\n"
        self.process.stdin.write(message_str.encode())
        await self.process.stdin.drain()
        
        response_line = await self.process.stdout.readline()
        if response_line:
            return json.loads(response_line.decode().strip())
        return {}
    
    async def _list_tools(self):
        """Get list of available tools."""
        response = await self._send_message({
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/list"
        })
        
        if "result" in response and "tools" in response["result"]:
            self.available_tools = response["result"]["tools"]
    
    async def _list_resources(self):
        """Get list of available resources."""
        response = await self._send_message({
            "jsonrpc": "2.0",
            "id": 3,
            "method": "resources/list"
        })
        
        if "result" in response and "resources" in response["result"]:
            self.available_resources = response["result"]["resources"]
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> str:
        """Call a specific tool."""
        response = await self._send_message({
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments
            }
        })
        
        if "result" in response and "content" in response["result"]:
            content = response["result"]["content"]
            if content and len(content) > 0:
                return content[0].get("text", "No result")
        return "Tool execution failed"
    
    async def stop_server(self):
        """Stop the MCP server."""
        if self.process:
            self.process.terminate()
            await self.process.wait()

class AIAgent:
    """AI Agent that uses MCP for tool integration."""
    
    def __init__(self):
        self.openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.mcp_client = None
        self.conversation_history = []
    
    async def initialize(self):
        """Initialize the AI agent with MCP server."""
        # Start MCP server
        self.mcp_client = MCPClient(["python", "mcp_server.py"])
        await self.mcp_client.start_server()
        
        print("🤖 AI Agent with MCP initialized!")
        print(f"Available tools: {[tool['name'] for tool in self.mcp_client.available_tools]}")
        print(f"Available resources: {[resource['name'] for resource in self.mcp_client.available_resources]}")
    
    def _create_system_prompt(self) -> str:
        """Create system prompt with available tools."""
        tools_info = []
        for tool in self.mcp_client.available_tools:
            tools_info.append(f"- {tool['name']}: {tool['description']}")
        
        return f"""You are a helpful AI assistant with access to the following tools via MCP:

{chr(10).join(tools_info)}

When you need to use a tool, respond with a JSON object in this format:
{{"tool_call": {{"name": "tool_name", "arguments": {{"param": "value"}}}}}}

Always explain what you're doing and interpret the results for the user.
"""
    
    async def process_message(self, user_message: str) -> str:
        """Process user message and potentially call tools."""
        # Add user message to history
        self.conversation_history.append({"role": "user", "content": user_message})
        
        # Get AI response
        messages = [
            {"role": "system", "content": self._create_system_prompt()},
            *self.conversation_history
        ]
        
        response = self.openai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content
        
        # Check if AI wants to call a tool
        if "tool_call" in ai_response:
            try:
                # Extract tool call
                import re
                tool_call_match = re.search(r'\{"tool_call".*?\}', ai_response)
                if tool_call_match:
                    tool_call_json = json.loads(tool_call_match.group())
                    tool_call = tool_call_json["tool_call"]
                    
                    # Execute tool
                    tool_result = await self.mcp_client.call_tool(
                        tool_call["name"], 
                        tool_call["arguments"]
                    )
                    
                    # Get AI to interpret the result
                    interpretation_messages = messages + [
                        {"role": "assistant", "content": ai_response},
                        {"role": "user", "content": f"Tool result: {tool_result}. Please interpret this result for the user."}
                    ]
                    
                    interpretation_response = self.openai_client.chat.completions.create(
                        model="gpt-3.5-turbo",
                        messages=interpretation_messages,
                        temperature=0.7
                    )
                    
                    final_response = interpretation_response.choices[0].message.content
                    self.conversation_history.append({"role": "assistant", "content": final_response})
                    return final_response
            
            except Exception as e:
                error_response = f"Error executing tool: {str(e)}"
                self.conversation_history.append({"role": "assistant", "content": error_response})
                return error_response
        
        # No tool call needed
        self.conversation_history.append({"role": "assistant", "content": ai_response})
        return ai_response
    
    async def run_interactive(self):
        """Run interactive chat loop."""
        print("\n💬 Chat with your AI Agent (type 'quit' to exit)")
        print("Try asking: 'What time is it?', 'Calculate 25 * 8', 'Weather in Tokyo'\n")
        
        while True:
            try:
                user_input = input("You: ").strip()
                
                if user_input.lower() in ['quit', 'exit', 'bye']:
                    print("👋 Goodbye!")
                    break
                
                if not user_input:
                    continue
                
                response = await self.process_message(user_input)
                print(f"Agent: {response}\n")
                
            except KeyboardInterrupt:
                print("\n👋 Goodbye!")
                break
            except Exception as e:
                print(f"Error: {e}\n")
    
    async def cleanup(self):
        """Clean up resources."""
        if self.mcp_client:
            await self.mcp_client.stop_server()

async def main():
    """Main function to run the AI agent."""
    agent = AIAgent()
    
    try:
        await agent.initialize()
        await agent.run_interactive()
    finally:
        await agent.cleanup()

if __name__ == "__main__":
    asyncio.run(main())