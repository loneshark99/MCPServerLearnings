import asyncio
from mcp_client import AIAgent

async def demo_agent():
    """Demonstrate the AI agent capabilities."""
    agent = AIAgent()
    
    try:
        await agent.initialize()
        
        # Demo conversations
        test_messages = [
            "What time is it?",
            "Calculate 15 * 23 + 100",
            "What's the weather like in London?",
            "Search for information about Python programming"
        ]
        
        print("🚀 Running AI Agent Demo\n")
        
        for message in test_messages:
            print(f"User: {message}")
            response = await agent.process_message(message)
            print(f"Agent: {response}\n")
            await asyncio.sleep(1)  # Brief pause between messages
        
        print("Demo completed! Starting interactive mode...\n")
        await agent.run_interactive()
        
    finally:
        await agent.cleanup()

if __name__ == "__main__":
    asyncio.run(demo_agent())