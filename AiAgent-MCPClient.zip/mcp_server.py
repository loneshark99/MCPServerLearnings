import asyncio
import json
import logging
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Resource, Tool, TextContent
import requests
from datetime import datetime
import os

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create MCP server instance
server = Server("ai-agent-tools")

@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools for the AI agent."""
    return [
        Tool(
            name="get_current_time",
            description="Get the current date and time",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        Tool(
            name="calculate",
            description="Perform mathematical calculations",
            inputSchema={
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "description": "Mathematical expression to evaluate"
                    }
                },
                "required": ["expression"]
            }
        ),
        Tool(
            name="get_weather",
            description="Get weather information for a city",
            inputSchema={
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "Name of the city"
                    }
                },
                "required": ["city"]
            }
        ),
        Tool(
            name="search_web",
            description="Search the web for information",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query"
                    }
                },
                "required": ["query"]
            }
        )
    ]

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Execute the requested tool."""
    try:
        if name == "get_current_time":
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
            return [TextContent(type="text", text=f"Current time: {current_time}")]
        
        elif name == "calculate":
            expression = arguments.get("expression", "")
            try:
                # Safe evaluation for basic math
                allowed_chars = "0123456789+-*/.() "
                if all(c in allowed_chars for c in expression):
                    result = eval(expression)
                    return [TextContent(type="text", text=f"Result: {expression} = {result}")]
                else:
                    return [TextContent(type="text", text="Error: Invalid expression")]
            except Exception as e:
                return [TextContent(type="text", text=f"Calculation error: {str(e)}")]
        
        elif name == "get_weather":
            city = arguments.get("city", "")
            # Mock weather data for demo
            weather_data = {
                "new york": "Sunny, 72°F (22°C)",
                "london": "Cloudy, 59°F (15°C)", 
                "tokyo": "Rainy, 68°F (20°C)",
                "paris": "Partly cloudy, 64°F (18°C)",
                "seattle": "Rainy, 55°F (13°C)"
            }
            
            weather = weather_data.get(city.lower(), f"Weather data not available for {city}")
            return [TextContent(type="text", text=f"Weather in {city}: {weather}")]
        
        elif name == "search_web":
            query = arguments.get("query", "")
            # Mock search results for demo
            mock_results = [
                f"Search result 1 for '{query}': Relevant information found",
                f"Search result 2 for '{query}': Additional context available",
                f"Search result 3 for '{query}': More details here"
            ]
            results_text = "\n".join(mock_results)
            return [TextContent(type="text", text=f"Search results for '{query}':\n{results_text}")]
        
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
            
    except Exception as e:
        logger.error(f"Tool execution error: {e}")
        return [TextContent(type="text", text=f"Tool error: {str(e)}")]

@server.list_resources()
async def list_resources() -> list[Resource]:
    """List available resources."""
    return [
        Resource(
            uri="agent://system-info",
            name="System Information",
            description="Current system and agent information",
            mimeType="text/plain"
        )
    ]

@server.read_resource()
async def read_resource(uri: str) -> str:
    """Read a specific resource."""
    if uri == "agent://system-info":
        info = {
            "agent_name": "MCP AI Agent",
            "version": "1.0.0",
            "capabilities": ["time", "calculator", "weather", "search"],
            "current_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
        }
        return json.dumps(info, indent=2)
    else:
        raise ValueError(f"Unknown resource: {uri}")

async def main():
    """Run the MCP server."""
    logger.info("Starting MCP server...")
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )

if __name__ == "__main__":
    asyncio.run(main())